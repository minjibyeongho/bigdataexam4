package product;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import bean.BoardDTO;

public class productDAO {

	DBConnectionMgr mgr;
	
	public productDAO(){
		mgr = DBConnectionMgr.getInstance();	//싱글톤으로 없으면 만들어주고 있으면 있는걸 당겨옴~
	}
	
	public void Insert(productDTO dto) throws Exception{
		//1, 2단계를 해주는 DBConnectionMgr객체 필요
		Connection con = mgr.getConnection();	//mgr객체는 connection이 10개 만들어져 있고 이중 1개를 가져온 것을 의미
		
		//3단계. SQL문 결정
		String sql = "insert into myshop(id, title, detail, price)  values(?,?,?,?)";
		
		PreparedStatement ps = con.prepareStatement(sql);
		// 게시글 번호는 auto_increment로 자동으로 들어가니까 넣지 않는다.
		ps.setString(1, dto.getId());
		ps.setString(2, dto.getTitle());
		ps.setString(3, dto.getDetail());
		ps.setInt(4, dto.getPrice());

		//4단계. SQL문 실행 요청
		ps.executeUpdate();
		mgr.freeConnection(con, ps);
		
	}
	
	public void Update(productDTO dto) throws Exception{
		//1, 2단계를 해주는 DBConnectionMgr객체 필요
		Connection con = mgr.getConnection();	//mgr객체는 connection이 10개 만들어져 있고 이중 1개를 가져온 것을 의미
		
		//3단계. SQL문 결정
		String sql = "update myshop set detail=?,price=? where id = ?";
		// num값을 물고 content, title을 바꿀 수 있도록
		PreparedStatement ps = con.prepareStatement(sql);
		// 게시글 번호는 auto_increment로 자동으로 들어가니까 넣지 않는다.
		ps.setString(1, dto.getDetail());
		ps.setInt(2, dto.getPrice());
		ps.setString(3, dto.getId());

		//4단계. SQL문 실행 요청
		ps.executeUpdate();
		mgr.freeConnection(con, ps);
		
	}

	public void Delete(String id) throws Exception{
		//1, 2단계를 해주는 DBConnectionMgr객체 필요
		Connection con = mgr.getConnection();	//mgr객체는 connection이 10개 만들어져 있고 이중 1개를 가져온 것을 의미
		
		//3단계. SQL문 결정
		String sql = "delete from myshop where id = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, id);

		//4단계. SQL문 실행 요청
		ps.executeUpdate();
		mgr.freeConnection(con, ps);
		
	}

	public productDTO Select(String id) throws Exception{
		//1, 2단계를 해주는 DBConnectionMgr객체 필요
		Connection con = mgr.getConnection();	//mgr객체는 connection이 10개 만들어져 있고 이중 1개를 가져온 것을 의미
		ResultSet rs =null;
		//3단계. SQL문 결정
		String sql = "select * from myshop where id=?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, id);
		//4단계. SQL문 실행 요청
		rs = ps.executeQuery();
		//5단계. SQL문 실행 결과 Resultset에 가져오기
		productDTO dto = null;
		if(rs.next()) {
			dto = new productDTO();
			
			String id2 = rs.getString(1);
			String title = rs.getString(2);
			String detail = rs.getString(3);
			int price = rs.getInt(4);
			
			dto.setId(id2);
			dto.setTitle(title);
			dto.setDetail(detail);
			dto.setPrice(price);
			//dto에 찾은 값 가져오기 완료
			
			
		}
		mgr.freeConnection(con, ps, rs);
		return dto;
	}	
	
	public ArrayList<productDTO> SelectAll() throws Exception{
		ArrayList<productDTO> list = new ArrayList<>();
		//1, 2단계를 해주는 DBConnectionMgr객체 필요
		Connection con = mgr.getConnection();	//mgr객체는 connection이 10개 만들어져 있고 이중 1개를 가져온 것을 의미
		ResultSet rs =null;
		
		
		//3단계. SQL문 결정
		String sql = "select * from myshop";
		
		PreparedStatement ps = con.prepareStatement(sql);
		// 게시글 번호는 auto_increment로 자동으로 들어가니까 넣지 않는다.
		

		//4단계. SQL문 실행 요청
		rs = ps.executeQuery();
		
		//5단계. SQL문 실행 결과 Resultset에 가져오기
		
		productDTO dto = null;
		
		while(rs.next()) {
			dto = new productDTO();
			
			String id2 = rs.getString(1);
			String title = rs.getString(2);
			String detail = rs.getString(3);
			int price = rs.getInt(4);
			
			dto.setId(id2);
			dto.setTitle(title);
			dto.setDetail(detail);
			dto.setPrice(price);
			
			list.add(dto);	//dto를 완성해서 arraylist에 넣어줌
		}
		
		mgr.freeConnection(con, ps, rs);
		return list;
	}
	
	
}
